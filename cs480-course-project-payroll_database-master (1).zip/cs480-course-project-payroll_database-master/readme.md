## Table of Contents
1. [Database](#database)
1. [Author(s)](#author)
1. [Database description](#description)

# Database
payroll_database

# Author(s)
Sanket Shah
Vedant Majmudar

# Database description
We are making a database of a payroll management company. This company holds contracts with other companies for handling their employee's pay data. This includes details about employes like username, employee id, name, and many more. Also, it keeps the record of the play data for the pay week, the number of hours worked, taxes, deductibles, and many more things in detail. A collection of data can help us analyze how much an average employee makes and how much actually goes in his pockets. 
